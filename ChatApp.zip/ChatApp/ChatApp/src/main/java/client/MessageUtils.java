// client/MessageUtils.java
package client;

import java.util.Random;

public class MessageUtils {
    private static int messageCounter = 1;

    public static String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public static boolean checkMessageID(String messageID) {
        return messageID.length() == 10;
    }

    public static boolean checkRecipientCell(String cell) {
        return cell.matches("^\\+\\d{9,10}$");
    }

    public static String createMessageHash(String messageID, int msgNum, String message) {
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return (messageID.substring(0, 2) + ":" + msgNum + ":" + first + last).toUpperCase();
    }

    public static int getNextMessageNumber() {
        return messageCounter++;
    }
}
