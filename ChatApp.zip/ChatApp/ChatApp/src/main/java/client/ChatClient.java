// client/ChatClient.java
package client;

import server.Message;

import javax.swing.*;
import java.util.*;
import java.io.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ChatClient {
    static List<Message> sentMessages = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to QuickChat.");

        boolean isLoggedIn = true; // Replace with real login check in future
        if (!isLoggedIn) {
            System.out.println("Login required.");
            return;
        }

        while (true) {
            System.out.println("\nChoose an option:\n1. Send Messages\n2. Show Recently Sent Messages\n3. Quit");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    sendMessages();
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid input. Try again.");
            }
        }
    }

    public static void sendMessages() {
        System.out.print("How many messages would you like to send? ");
        int count = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < count; i++) {
            String messageID = MessageUtils.generateMessageID();
            while (!MessageUtils.checkMessageID(messageID)) {
                messageID = MessageUtils.generateMessageID();
            }

            System.out.print("Enter recipient number (+XXXXXXXXXX): ");
            String recipient = scanner.nextLine();
            if (!MessageUtils.checkRecipientCell(recipient)) {
                System.out.println("Cell phone number is incorrectly formatted or missing international code.");
                i--;
                continue;
            }

            System.out.print("Enter your message (max 250 characters): ");
            String content = scanner.nextLine();
            if (content.length() > 250) {
                System.out.println("Message exceeds 250 characters by " + (content.length() - 250) + ", please reduce size.");
                i--;
                continue;
            }

            int msgNum = MessageUtils.getNextMessageNumber();
            String hash = MessageUtils.createMessageHash(messageID, msgNum, content);

            System.out.println("Choose:\n1. Send Message\n2. Disregard\n3. Store for later");
            String option = scanner.nextLine();

            if (option.equals("2")) {
                System.out.println("Message disregarded.");
                continue;
            }

            Message msg = new Message(messageID, msgNum, recipient, content, hash);

            if (option.equals("3")) {
                storeMessageForLater(msg);
                System.out.println("Message stored for later.");
            } else {
                sentMessages.add(msg);
                showMessageDetails(msg);
            }
        }

        System.out.println("Total messages sent: " + sentMessages.size());
    }

    public static void showMessageDetails(Message msg) {
        JOptionPane.showMessageDialog(null,
            "MessageID: " + msg.getMessageID() +
            "\nMessage Hash: " + msg.getMessageHash() +
            "\nRecipient: " + msg.getRecipient() +
            "\nMessage: " + msg.getContent()
        );
    }

    public static void storeMessageForLater(Message msg) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter writer = new FileWriter("stored_messages.json", true)) {
            gson.toJson(msg, writer);
        } catch (IOException e) {
            System.out.println("Failed to store message.");
        }
    }
}
