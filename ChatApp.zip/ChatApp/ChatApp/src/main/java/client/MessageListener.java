package client;

import java.io.BufferedReader;
import java.io.IOException;

public class MessageListener implements Runnable {
    private final BufferedReader in;

    public MessageListener(BufferedReader in) {
        this.in = in;
    }

    @Override
    public void run() {
        String message;
        try {
            while ((message = in.readLine()) != null) {
                System.out.println(message);
            }
        } catch (IOException e) {
            System.err.println("Disconnected from server.");
        }
    }
}
