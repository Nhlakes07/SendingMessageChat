import client.MessageUtils;
import static org.junit.Assert.*;
import org.junit.Test;

public class MessageUtilsTest {

    @Test
    public void testValidMessageLength() {
        String msg = "Hello world!";
        assertTrue(msg.length() <= 250);
    }

    @Test
    public void testInvalidMessageLength() {
        String longMsg = "A".repeat(251);
        assertTrue(longMsg.length() > 250);
    }

    @Test
    public void testValidRecipient() {
        assertTrue(MessageUtils.checkRecipientCell("+1234567890"));
    }

    @Test
    public void testInvalidRecipient() {
        assertFalse(MessageUtils.checkRecipientCell("123456"));
    }

    @Test
    public void testMessageHashFormat() {
        String hash = MessageUtils.createMessageHash("1234567890", 1, "Hi thanks");
        assertEquals("12:1:HITHANKS", hash);
    }
}
