package common;

public enum MessageType {
    TEXT,       // Regular text message
    JOIN,       // User has joined the chat
    LEAVE,      // User has left the chat
    SYSTEM      // System-generated message (e.g., errors, alerts)
}
