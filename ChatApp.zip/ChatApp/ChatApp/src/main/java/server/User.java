package server;

public class User {
    private String username;
    private int id; // Could be used for unique identification

    public User(String username, int id) {
        this.username = username;
        this.id = id;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public int getId() {
        return id;
    }

    // Setters
    public void setUsername(String username) {
        this.username = username;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "'}";
    }
}
