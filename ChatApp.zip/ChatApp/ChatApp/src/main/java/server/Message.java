package server;

import common.MessageType;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Message implements Serializable {
    private String sender;
    private String content;
    private MessageType type;
    private LocalDateTime timestamp;

    public Message(String sender, String content, MessageType type) {
        this.sender = sender;
        this.content = content;
        this.type = type;
        this.timestamp = LocalDateTime.now();
    }

    // Getters
    public String getSender() {
        return sender;
    }

    public String getContent() {
        return content;
    }

    public MessageType getType() {
        return type;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    // Optional toString() for debugging
    @Override
    public String toString() {
        return "[" + timestamp + "] " + sender + ": " + content;
    }
}
